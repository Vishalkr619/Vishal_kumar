package com.Proposals;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProposalsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProposalsApplication.class, args);
	}

}
