package com.Proposals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProposalsApplicationTests {

	@Test
	void contextLoads() {
	}

}
